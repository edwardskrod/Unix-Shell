#pragma once

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define _XOPEN_SOURCE 700
#define SIZE 100

char ** pathParser();
